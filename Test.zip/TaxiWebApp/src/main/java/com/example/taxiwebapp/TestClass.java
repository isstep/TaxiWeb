package com.example.taxiwebapp;

import com.example.taxiwebapp.EntityClasses.Roles;
import com.example.taxiwebapp.EntityRepositories.RoleRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;

@SpringBootApplication
public class TestClass {
    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(TestClass.class, args);

        RoleRepository repository = context.getBean(RoleRepository.class);

        List<Roles> allRoles = (List<Roles>) repository.findAll();

        for (Roles user : allRoles) {
            System.out.println(user.getId() + " " + user.getRoleName());
        }
    }
}
