package com.example.taxiwebapp.EntityRepositories;

import com.example.taxiwebapp.EntityClasses.Roles;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RoleRepository extends CrudRepository<Roles, Integer> {
    @Query("SELECT id, role_Name FROM Roles")
    List<Roles> findAll();
}
