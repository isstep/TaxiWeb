package com.example.taxiwebapp.EntityClasses;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Table("Roles")
public class Roles {

    @Id
    private Integer id;

    private String roleName;

    public Integer getId() {
        return id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}