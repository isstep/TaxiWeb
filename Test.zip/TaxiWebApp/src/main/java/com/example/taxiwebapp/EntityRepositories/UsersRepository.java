package com.example.taxiwebapp.EntityRepositories;

import org.springframework.data.relational.core.mapping.Table;


public interface UsersRepository {
}
