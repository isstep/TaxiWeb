package com.example.taxiwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxiWebAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
