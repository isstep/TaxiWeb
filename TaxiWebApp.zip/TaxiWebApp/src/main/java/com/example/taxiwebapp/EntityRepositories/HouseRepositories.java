package com.example.taxiwebapp.EntityRepositories;

import com.example.taxiwebapp.EntityClasses.HouseEntity;
import org.springframework.data.repository.CrudRepository;

public interface HouseRepositories extends CrudRepository<HouseEntity,Long> {
}
