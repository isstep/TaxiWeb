package com.example.taxiwebapp.EntityRepositories;

import com.example.taxiwebapp.EntityClasses.UsersEntity;

import org.springframework.data.repository.CrudRepository;


public interface UsersRepository extends CrudRepository<UsersEntity,Long> {
    UsersEntity findByUsername(String username);
}
