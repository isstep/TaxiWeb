package com.example.taxiwebapp.EntityRepositories;

import com.example.taxiwebapp.EntityClasses.CitiesEntity;
import org.springframework.data.repository.CrudRepository;

public interface CitiesRepository extends CrudRepository<CitiesEntity,Long> {
}
