package com.example.taxiwebapp.EntityRepositories;

import com.example.taxiwebapp.EntityClasses.DistrictEntity;
import org.springframework.data.repository.CrudRepository;

public interface DistrictRepository extends CrudRepository<DistrictEntity,Long>{
}
