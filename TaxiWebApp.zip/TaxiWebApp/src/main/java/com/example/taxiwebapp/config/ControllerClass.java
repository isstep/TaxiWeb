package com.example.taxiwebapp.config;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControllerClass {

    @GetMapping("/login")
    public String EntryPage(Model model){
        return "LoginPage";
    }
}
