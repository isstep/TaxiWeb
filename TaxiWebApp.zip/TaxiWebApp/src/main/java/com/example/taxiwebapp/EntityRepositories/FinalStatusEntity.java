package com.example.taxiwebapp.EntityRepositories;

import org.springframework.data.repository.CrudRepository;

public interface FinalStatusEntity extends CrudRepository<FinalStatusEntity,Long>{
}
