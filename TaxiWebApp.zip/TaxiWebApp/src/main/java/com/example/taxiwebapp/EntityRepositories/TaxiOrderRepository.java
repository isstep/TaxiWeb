package com.example.taxiwebapp.EntityRepositories;

import com.example.taxiwebapp.EntityClasses.TaxiOrderEntity;
import org.springframework.data.repository.CrudRepository;

public interface TaxiOrderRepository extends CrudRepository<TaxiOrderEntity,Long> {
}
