package com.example.taxiwebapp.ServiceMethods;

import com.example.taxiwebapp.EntityClasses.RolesEntity;
import com.example.taxiwebapp.EntityClasses.UsersEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserService userService;
    private final RoleService roleService;

    public UserDetailsServiceImpl(UserService userService, RoleService roleService) {
        this.userService = userService;
        this.roleService = roleService;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UsersEntity user = userService.findByUsername(username);

        if (user == null) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }

        RolesEntity role = roleService.findByRoleId(user.getRoleId());

        // Создаем UserDetails объект, представляющий пользователя в Spring Security
        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password(user.getUserPassword())
                .roles(new String[]{role.getRoleName()})  // Передаем массив с одним элементом
                .build();
    }


}